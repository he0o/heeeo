<h2 align="center">
    ─ ダ𓏺َِ᥉َِ᥆َِꪊَِᖇَِᥴُِ꧖ َِ᥉َِρُِꪖَِᖇَِᥴُِƙَِ」──
</h2>

<p align="center">
  <img src="https://graph.org/file/2577f47589c4b4c63e4a6.jpg">
</p>

